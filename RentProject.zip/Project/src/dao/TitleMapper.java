package dao;

import java.util.ArrayList;
import java.util.HashMap;

import vo.Title;

public interface TitleMapper {
	
	public int insertTitle(Title temp);

	public ArrayList<Title> listTitle();

	public int deleteTitle(int n);

	public ArrayList<Title> searchTitle(HashMap<String, Object> map);

	public int updateTitle(Title title);
	
}
