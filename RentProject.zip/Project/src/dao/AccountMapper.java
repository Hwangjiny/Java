package dao;

import java.util.ArrayList;

import vo.Account;

public interface AccountMapper {
	
	public int memberLogin(Account aco);
	
	public int insertMember(Account aco);
	
	public ArrayList<Account> listMember();
	
	public Account searchMember(String personNum);

	public int deleteMember(String personNum);

	public int updateMember(Account temp);

	

	



}
