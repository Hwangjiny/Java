package dao;

public interface AdminMapper {

	void plusRentMoney();

	void plusExtendMoney();

	int checkAdminMoney();

}
