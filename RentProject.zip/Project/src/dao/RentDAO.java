package dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import vo.Account;
import vo.RentList;
import vo.Title;

public class RentDAO {
	SqlSessionFactory factory = MybatisConfig.getSqlSessionFactory();

	public boolean memberLogin(Account aco) {
		SqlSession session = null;
		int result = 0;
		try {
			session = factory.openSession();
			AccountMapper mapper = session.getMapper(AccountMapper.class);
			result = mapper.memberLogin(aco);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) session.close();
		}
		return result > 0;
	}
	
	public boolean insertMember(Account aco) {
		SqlSession session = null;
		int result = 0;
		try {
			session = factory.openSession();
			AccountMapper mapper = session.getMapper(AccountMapper.class);
			result = mapper.insertMember(aco);
			session.commit();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) session.close();
		}
		return result > 0;
	}
	
	public Account searchMember(String personNum) {
		SqlSession session = null;
		Account result = null;
		
		try {
			session = factory.openSession();
			AccountMapper mapper = session.getMapper(AccountMapper.class);
			result = mapper.searchMember(personNum);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) session.close();
		}
		return result;
	}

	public boolean deleteMember(String person_Num) {
		SqlSession session = null;
		int result = 0;
		
		try {
			session = factory.openSession();
			AccountMapper mapper = session.getMapper(AccountMapper.class);
			result = mapper.deleteMember(person_Num);
			session.commit();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) session.close();
		}
		return result > 0;
	}
	
	public ArrayList<Account> listMember() {
		SqlSession session = null;
		ArrayList<Account>result = null;
		
		try {
			session = factory.openSession();
			AccountMapper mapper = session.getMapper(AccountMapper.class);
			result = mapper.listMember();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) session.close();
		}
		return result;
	}

	public boolean updateMember(Account temp) {
		SqlSession session = null;
		int res = 0;
		try {
			session = factory.openSession();
			AccountMapper mapper = session.getMapper(AccountMapper.class);
			res = mapper.updateMember(temp);
			session.commit();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (session != null) 
				session.close();
		}
		return res > 0;
	}
	
	
////////////////////////////////////////////////////////////////////////////////////////////////////

	public boolean insertTitle(Title temp) {
		SqlSession session = null;
		int result = 0;

		try {
			session = factory.openSession();
			TitleMapper mapper = session.getMapper(TitleMapper.class);
			result = mapper.insertTitle(temp);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return result > 0;
	}

	public ArrayList<Title> listTitle() {
		SqlSession session = null;
		ArrayList<Title> list = null;

		try {
			session = factory.openSession();
			TitleMapper mapper = session.getMapper(TitleMapper.class);
			list = mapper.listTitle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return list;
	}

	public boolean deleteTitle(int n) {
		SqlSession session = null;
		int res = 0;
		try {
			session = factory.openSession();
			TitleMapper mapper = session.getMapper(TitleMapper.class);
			res = mapper.deleteTitle(n);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (session != null) {
				session.close();
				}
		}
			if (res > 0) return true;
				// 리설트는 삭제한 로우의 수 (삭제가 성공했다면 무조건 로우의 수가 1이상이므로 트루가 되면서)
			return false;
	}


	public ArrayList<Title> searchTitle(int col, String word) {
		
		SqlSession session = null;
		ArrayList<Title> list = null;
		HashMap<String, Object> map = new HashMap<>();
		map.put("col", col); // 1,2,3)1이름 2 장르 3 날짜}
		map.put("word", word);

		try {
			session = factory.openSession();
			TitleMapper mapper = session.getMapper(TitleMapper.class);
			list = mapper.searchTitle(map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return list;
	}

	public boolean updateTitle(Title title) {
		SqlSession session = null;
		int res = 0;
		try {
			session = factory.openSession();
			TitleMapper mapper = session.getMapper(TitleMapper.class);
			res = mapper.updateTitle(title);
			session.commit();
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (session != null) 
				session.close();
		}
		return res>0;
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public ArrayList<Title> rentableList(int col, String word) {
		
		SqlSession session = null;
		ArrayList<Title> list = null;
		HashMap<String, Object> map = new HashMap<>();
		map.put("col", col); // 1,2,3)1이름 2 장르 3 날짜}
		map.put("word", word);

		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			list = mapper.rentableList(map);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return list;
	}

	public boolean rentTitle(RentList temp) {
		SqlSession session = null;
		int result = 0;
		
		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			result = mapper.rentTitle(temp);
			session.commit();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null) session.close();
		}
		return result > 0;
	}

	public void rentTitle2(int titleNum) {
		SqlSession session = null;
		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			mapper.rentTitle2(titleNum);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		
	}

	public int personNumToacoNum(String loginpersonNum) {
		SqlSession session = null;
		int result = 0;
		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			result = mapper.personNumToacoNum(loginpersonNum);
					
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null) session.close();
		}
		
		return result;
	}


	public ArrayList<Title> rentList(int i) {
		SqlSession session = null;
		ArrayList<Title> list = null;
		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			list = mapper.rentList(i);
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) session.close();
		}
		
		return list;
	}
	
////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void plusRentMoney() {
		SqlSession session = null;
		
		try {
			session = factory.openSession();
			AdminMapper mapper = session.getMapper(AdminMapper.class);
			mapper.plusRentMoney();
			session.commit();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null)session.close();
		}
	}
	
	public void plusExtendMoney() {
		SqlSession session = null;
		
		try {
			session = factory.openSession();
			AdminMapper mapper = session.getMapper(AdminMapper.class);
			mapper.plusExtendMoney();
			session.commit();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null)session.close();
		}
	}
	
	public int checkAdminMoney() {
		SqlSession session = null;
		int result = 0;
		try {
			session = factory.openSession();
			AdminMapper mapper = session.getMapper(AdminMapper.class);
			result = mapper.checkAdminMoney();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session!=null) session.close();
		}
		return result;
	}


	public ArrayList<Title> notrentableList() {
		SqlSession session = null;
		ArrayList<Title> list = null;
		
		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			list = mapper.notrentableList();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) session.close();
		}
		return list;
	}

	public boolean returnTitle(int titleNum) {
		SqlSession session = null;
		int result = 0;

		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			result = mapper.returnTitle(titleNum);
			session.commit();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) session.close();
		}
		return result > 0;
	}

	public void returnTitle2(int titleNum) {
		SqlSession session = null;
		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			mapper.returnTitle2(titleNum);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		
	}

	public String getReturnDate(int title_num) {
		SqlSession session = null;
		String result = null;
		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			result = mapper.getReturnDate(title_num);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return result;
	}

	public boolean plusReturnDate(int titleNum) {
		SqlSession session = null;
		int result = 0;
		try {
			session = factory.openSession();
			RentMapper mapper = session.getMapper(RentMapper.class);
			result = mapper.plusReturnDate(titleNum);
			session.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null)
				session.close();
		}
		return result > 0;
	}


}
