package dao;

import java.util.ArrayList;
import java.util.HashMap;

import vo.RentList;
import vo.Title;

public interface RentMapper {
	
	public ArrayList<Title> rentableList(HashMap<String, Object> map);

	public int rentTitle(RentList temp);

	public int rentTitle2(int titleNum);

	public int personNumToacoNum(String loginpersonNum);

	public ArrayList<Title> rentList(int i);

	public ArrayList<Title> notrentableList();

	public int returnTitle(int titleNum);

	public int returnTitle2(int titleNum);

	public String getReturnDate(int title_num);

	public int plusReturnDate(int titleNum);
}
