package main;

import java.util.ArrayList;
import java.util.Scanner;

import dao.RentDAO;
import vo.Account;
import vo.RentList;
import vo.Title;

public class UI {
	private Scanner sc = new Scanner(System.in);
	private RentDAO dao = new RentDAO();
	private String PW = "admin"; //관리자 비번 설정
	private String loginpersonNum = null; //로그인 시 입력받은 주민번호 저장할 공간
	
	public UI() {
			while(true) {
				printMainMenu();
				
				int no = 0;
				try {
					no = sc.nextInt();
				}
				catch (Exception e) {	
					sc.nextLine();		
				}
				switch(no){
					case 1:  
						if(adminLogin()) {
							System.out.println("로그인 성공\n");
							AdminMenu();
						} else {
							System.out.println("올바르지 않은 비밀번호\n");
						}
						break;
					case 2: 
						if (memberLogin()) {
							System.out.println("환영합니다.***\n");
							MemberMenu();
						} else {
							System.out.println("아이디 혹은 패스워드가 올바르지 않습니다.");
						}
						break;
					case 3:
						memberReg();
						break;
					case 9: 
						System.out.println("프로그램을 종료합니다.");
						System.exit(0);
						break;
					default:
						System.out.println("번호를 다시 선택하세요.");
				}
			}
		}
	
	
	public boolean adminLogin() { //static 변수 PW로 관리자 비번 설정
		System.out.print("관리자 비밀번호 입력 : ");
		String adminPW = sc.next();
		return adminPW.equals(PW);
	}

	public boolean memberLogin() {
		sc.nextLine();
		System.out.print("주민번호 입력 : ");
		String personNum = sc.nextLine();
		System.out.print("비밀번호 입력 : ");
		String password = sc.nextLine();
		loginpersonNum = personNum;
		
		ArrayList<Account>list = dao.listMember();
		if(list != null) {
			for(Account a : list) {
				if(a.getPerson_Num().equals(personNum) && a.getPassword().equals(password)) {
					System.out.print("***"+a.getName() +"님 ");
					return true;
				}
			} 
		}
		return false;
	}
	
	public void memberReg() {
		String name, person_Num, phone_Num, password;
		
		sc.nextLine();
		ArrayList<Account>list = dao.listMember();
		System.out.println("== 회원 등록 ==");
		System.out.print("이름 : ");
		name = sc.nextLine();
		System.out.print("주민등록번호 : ");
		person_Num = sc.nextLine();
		System.out.print("전화번호 : ");
		phone_Num = sc.nextLine();
		System.out.print("비밀번호 : ");
		password = sc.nextLine();
		
		for(Account aco : list) {
			if(aco.getPerson_Num().equals(person_Num)) {
				System.out.println("중복된 주민등록번호가 존재합니다.\n");
				return;
			}
		}
		
		Account aco = new Account(name, person_Num, phone_Num, password, 0);
		if(dao.insertMember(aco)) System.out.println("등록 성공");
		else System.out.println("등록 실패");
	}
	
	
	public void printMainMenu() {
		System.out.println("====DVD Rent System====\n");
		System.out.println("1. 관리자 로그인");
		System.out.println("2. 회원 로그인");
		System.out.println("3. 회원 등록");
		System.out.println("9. 프로그램 종료");
		System.out.println("\n========================");
		System.out.print("선택 : ");
	}
	public void printAdminMenu() {
		System.out.println("=====관리자 메뉴=====\n");
		System.out.println("1. 회원 관리");
		System.out.println("2. 타이틀 관리");
		System.out.println("3. 대여 및 금액확인");
		System.out.println("0. 로그아웃");
		System.out.println("\n==================");
		System.out.print("선택 : ");
	}
	public void printMemberMenu() {
		System.out.println("=====회원 메뉴=====\n");
		System.out.println("1. 대여 가능 타이틀 검색");
		System.out.println("2. 대여 내역 조회");
		System.out.println("0. 로그아웃");
		System.out.println("\n=================");
		System.out.print("선택 : ");
	}
	
	
	public void AdminMenu() {
		boolean flag = true;
		int no = 0;
		while (flag) {
			printAdminMenu();
			try {
				no = sc.nextInt();
			} catch (Exception e) {
				sc.nextLine();
			}
			switch (no) {
			case 1:
				MemberMngMenu();
				break;
			case 2:
				titleMngMenu();
				break;
			case 3:
				rentMngMenu();
				break;
			case 0:
				flag = false;
				break;
			default:
				System.out.println("올바른 숫자를 입력하세요.\n");
			}
		}
	}

	public void MemberMngMenu() {
		boolean flag = true;
			while (flag) {
				System.out.println("====회원 관리====\n");
				System.out.println("1. 회원 검색"); //Select
				System.out.println("2. 전체 출력"); //Select
				System.out.println("3. 회원 삭제"); //Delete
				System.out.println("4. 회원정보 변경 "); //Delete
				System.out.println("0. 상위 메뉴");
				System.out.println("\n================");
				System.out.print("선택 : ");
				
				int no = 0;
				try {
					no = sc.nextInt();
				}
				catch (Exception e) {	
					sc.nextLine();		
				}
				switch(no) {
				case 1:
					searchMember();
					break;
				case 2:
					listMember();
					break;
				case 3:
					deleteMember();
					break;
				case 4:
					updateMember();
					break;
				case 0:
					flag = false;
					break;
				default :
					System.out.println("올바른 숫자를 입력하세요.\n");
				}
			}
	}

	private void updateMember() {
		sc.nextLine();
		ArrayList<Account>list = dao.listMember();
		System.out.println("=====회원정보 수정=====\n");
		System.out.print("수정할 회원번호 : ");
		int num = 0;
		String name, person_Num, phone_Num;

		try {
			num = sc.nextInt();
		} catch (Exception e) {
			sc.nextLine();
		}
		sc.nextLine();
		System.out.print("수정할 이름 : ");
		name = sc.nextLine();
		System.out.print("수정할 주민등록번호 : ");
		person_Num = sc.nextLine();
		System.out.print("수정할 전화번호 : ");
		phone_Num = sc.nextLine();

		for(Account aco : list) {
			if(aco.getPerson_Num().equals(person_Num)) {
				System.out.println("수정 실패하였습니다.");
				System.out.println("중복된 주민등록번호가 존재합니다.\n");
				return;
			}
		}
		Account temp = new Account(num, name, person_Num, phone_Num);
		boolean res = dao.updateMember(temp);
		if (res)
			System.out.println("수정되었습니다.\n");
		else
			System.out.println("수정 실패하였습니다.\n");
		
	}

	private void deleteMember() {
		sc.nextLine();
		System.out.println("=====회원 삭제=====\n");
		System.out.print("삭제하실 회원의 주민번호 : ");
		String personNum2 = sc.nextLine();
		if(dao.deleteMember(personNum2)) System.out.println("삭제 성공\n");
		else System.out.println("삭제 실패\n");
	}
	
	public void searchMember() {
		sc.nextLine();
		System.out.println("=====회원 검색=====\n");
		System.out.print("검색하실 회원의 주민등록번호 : ");
		String personNum = sc.nextLine();
		loginpersonNum = personNum;
		
		Account ac = dao.searchMember(personNum);
		if (ac != null) {
			System.out.println("회원명\t\t주민등록번호\t\t전화번호");
			System.out.println("===================================================");
			System.out.print(ac.getName()+"\t\t"+ac.getPerson_Num()+"\t\t"+ac.getPhone_Num()+"\n");
			System.out.println("===================================================");
			
			System.out.println("=====회원 대여 내역=====\n");
			ArrayList<Title> list = dao.rentList(dao.personNumToacoNum(loginpersonNum));
			if (list == null || list.size() == 0) {
				System.out.println("대여 내역이 없습니다.\n");
				return;
			}
			System.out.println("번호\t\t타이틀명\t\t반납예정일");
			System.out.println("=============================================");
			for (Title t : list) {
				System.out.print(t.getTitle_num() + "\t\t");
				System.out.print(t.getTitle_name() + "\t\t");
				System.out.println(dao.getReturnDate(t.getTitle_num()));
			}
			
			System.out.println("\n=============================================");
		}
		else System.out.println("찾는 회원이 없습니다.\n");
	}
	
	public void listMember() {
		System.out.println("=====전체 출력=====\n");
		ArrayList<Account>list = dao.listMember();
		if (list == null || list.size() == 0) {
			System.out.println("등록된 정보가 없습니다."); 
			return;
			}
		else {
			System.out.println("회원번호\t\t회원명\t\t전화번호");
			System.out.println("=====================================");
			for(Account aco : list) {
				System.out.print(aco.getNum()+"\t\t"+aco.getName()+"\t\t"+aco.getPhone_Num()+"\n");
			}
			System.out.println("=====================================\n");
		}
	}
	
	
	
	public void titleMngMenu() {
		int no = 0;
		while (true) {
			System.out.println("=====타이틀 관리=====\n");
			System.out.println("1. 타이틀 등록");// insert
			System.out.println("2. 타이틀 검색");// Select 이름, 장르, 최신
			System.out.println("3. 타이틀 목록"); // list
			System.out.println("4. 타이틀 삭제");// Delete
			System.out.println("5. 타이틀 수정");// update
			System.out.println("0. 상위 메뉴");
			System.out.println("\n================");
			System.out.print("선택 : ");

			try {
				no = sc.nextInt();
			} catch (Exception e) {
				e.printStackTrace();
			}
			switch (no) {
			case 1:
				insertTitle();
				break;
			case 2:
				searchTitle();
				break;
			case 3:
				listTitle();
				break;
			case 4:
				deleteTitle();
				break;
			case 5:
				updateTitle();
				break;
			case 0:
				return;
			default:
				System.out.println("올바른 숫자를 입력하세요.\n");
			}
		}
	}

	void insertTitle() {
		String title_name = null;
		String title_genre = null;
		String title_date = null;

		try {
			sc.nextLine();
			System.out.println("=====타이틀 입력=====\n");
			System.out.print("영화 이름입력 : ");
			title_name = sc.nextLine();
			System.out.print("장르 입력 : ");
			title_genre = sc.nextLine();
			System.out.print("개봉연도 입력 : ");
			title_date = sc.nextLine();

		} catch (Exception e) {
			sc.nextLine();
			System.out.println("잘못 입력하셨습니다");
			return;
		}
		Title title = new Title(0, title_name, title_genre, title_date, 1);
		boolean isSuccess = dao.insertTitle(title);
		if (isSuccess)
			System.out.println("타이틀 입력 성공");
		else
			System.out.println("타이틀 입력 실패");
	}

	void searchTitle() {
		System.out.println("=====타이틀 검색=====\n");
		int col = 0;
		String word = null;
		try {
			System.out.println("검색 대상 : 1.영화제목 2.영화장르 3.개봉년도");
			col = sc.nextInt();

			System.out.println("검색어 : ");
			sc.nextLine();
			word = sc.nextLine();
		} catch (Exception e) {
			sc.nextLine();
			System.out.println("잘못된 입력입니다.");
			return;
		}
		ArrayList<Title> list = dao.searchTitle(col, word);
		if (list == null || list.size() == 0) {
			System.out.println("검색 결과가 없습니다.");
			return;
		} else {
			System.out.println("번호\t\t이름\t\t장르\t\t출시년도");
			System.out.println("=====================================");
			for (Title t : list) {
				System.out.print(t.getTitle_num() + "\t\t");
				System.out.print(t.getTitle_name() + "\t\t");
				System.out.print(t.getTitle_genre() + "\t\t");
				System.out.print(t.getTitle_date() + "\n");
				
			}
			System.out.println("=====================================");
		}
	}

	void listTitle() {
		ArrayList<Title> list = dao.listTitle();

		if (list == null || list.size() == 0)
			System.out.println("등록 정보가 없습니다.");
		else {
			System.out.println("번호\t\t이름\t\t장르\t\t출시년도\t\t대출가능여부");
			for (Title t : list) {
				System.out.print(t.getTitle_num() + "\t\t");
				System.out.print(t.getTitle_name() + "\t\t");
				System.out.print(t.getTitle_genre() + "\t\t");
				System.out.print(t.getTitle_date() + "\t\t");
				if (t.getRent_stat() == 0)
					System.out.println("대출중");
				else
					System.out.println("대출가능");
			}
		}
	}

	void updateTitle() {
		System.out.println("=====타이틀 수정=====\n");
		System.out.print("수정할 타이틀 번호 : ");
		int title_num = 0;
		String title_name, title_genre, title_date;

		try {
			title_num = sc.nextInt();
		} catch (Exception e) {
			sc.nextLine();
		}

		sc.nextLine();
		System.out.print("수정할 영화 이름 : ");
		title_name = sc.nextLine();
		System.out.print("수정할 영화 장르 : ");
		title_genre = sc.nextLine();
		System.out.print("수정할 영화 출시년도 : ");
		title_date = sc.nextLine();

		Title temp = new Title(title_num, title_name, title_genre, title_date);
		boolean res = dao.updateTitle(temp);

		if (res) System.out.println("수정 완료 되었습니다.\n");
		else System.out.println("수정 실패하였습니다.\n");
	}

	void deleteTitle() {
		System.out.println("=====타이틀 삭제=====\n");
		System.out.print("삭제할 타이틀 번호  : ");
		int n = 0;
		try {
			n = sc.nextInt();
		} catch (Exception e) {
			sc.nextLine();
		}
		boolean res = dao.deleteTitle(n);
		if (res) System.out.println("삭제 완료 되었습니다.\n");
		else System.out.println("삭제 실패하였습니다.\n");
	}
	
	private void rentMngMenu() {
		int no = 0;
		boolean flag = true;
		
		while(flag) {
			System.out.println("=====대여 현황 관리=====\n");
			System.out.println("1. 대여중인 타이틀");
			System.out.println("2. 현재 보유 금액");
			System.out.println("0. 상위 메뉴");
			System.out.println("\n================");
			System.out.print("선택 : ");
			try {
				no = sc.nextInt();
			}
			catch (Exception e) {	
				sc.nextLine();		
			}
			switch(no) {
			case 1:
				notrentbaleList();
				break;
			case 2:
				checkAdminMoney();
				break;
			case 0:
				flag = false;
				break;
			default:
				System.out.println("올바른 숫자를 입력하세요.\n");
			}
		}
		
	}
	
	private void checkAdminMoney() {
		int adminMoney = dao.checkAdminMoney();
		System.out.println("현재 보유 금액은 "+adminMoney+"원 입니다.\n");
	}


	private void notrentbaleList() {
		System.out.println("=====대여중인 타이틀=====\n");
		ArrayList<Title>list = dao.notrentableList();
		
		if (list == null || list.size() == 0)
			System.out.println("등록 정보가 없습니다.");
		else {
			System.out.println("번호\t\t이름\t\t장르\t\t반납예정일");
			System.out.println("=============================================================================");
			for (Title t : list) {
				System.out.print(t.getTitle_num() + "\t\t");
				System.out.print(t.getTitle_name() + "\t\t");
				System.out.print(t.getTitle_genre() + "\t\t");
				System.out.print(dao.getReturnDate(t.getTitle_num()) + "\t\t\n");
			}
			System.out.println("=============================================================================\n");
		}
	}
	
	public void MemberMenu() {
		boolean flag = true;
		int no = 0;
		while (flag) {
			printMemberMenu();
			try {
				no = sc.nextInt();
			} catch (Exception e) {
				sc.nextLine();
			}
			switch (no) {
			case 1:
				memberTitle();
				break;
			case 2:
				memberRent();
				break;
			case 0:
				flag = false;
				break;
			default:
				System.out.println("올바른 숫자를 입력하세요.\n");
			}
		}
	}
	
	private void memberTitle() {
		System.out.println("=====대여 가능 타이틀 검색=====\n");
		int col = 0;
		boolean flag = true;
		String word = null;
		try {
			while(flag) {
				System.out.println("검색 대상 : 1.제목 2.장르 3.개봉년도");
				col = sc.nextInt();
				if(col == 1 || col == 2 || col == 3) flag = false;
				else System.out.println("올바른 번호를 입력해 주세요.");
			}
			System.out.print("검색어 : ");
			sc.nextLine();
			word = sc.nextLine();
		}catch (Exception e) {
			sc.nextLine();
			System.out.println("잘못된 입력입니다.");
			return;
		}
		ArrayList<Title> list = dao.rentableList(col, word);
		if (list == null || list.size() == 0) {
			System.out.println("검색 결과가 없습니다.\n");
			return;
		}else {
			System.out.println("번호\t\t이름\t\t장르\t\t출시년도");
			System.out.println("===================================================");
			 for(Title t : list) {
					System.out.print(t.getTitle_num() + "\t\t");
					System.out.print(t.getTitle_name() + "\t\t");
					System.out.print(t.getTitle_genre() + "\t\t");
					System.out.print(t.getTitle_date() + "\n");
			 }
			System.out.println("===================================================");
		}
		
		int titleNum = 0;
		int acoNum = dao.personNumToacoNum(loginpersonNum);//로그인 시 받은 주민번호를 acoNum으로 변환한다.
		try {
			System.out.print("\n대출할 타이틀 번호 입력 : ");
			titleNum = sc.nextInt();
			
		}catch (Exception e) {
			sc.nextLine();
			System.out.println("잘못된 입력입니다.");
			return;
		}
		for (Title t : list) {
			if (t.getTitle_num() == titleNum) {
				RentList temp = new RentList(acoNum, titleNum);

				boolean result = dao.rentTitle(temp); // 렌트리스트에 값 입력 쿼리 메소드
				if (result) {
					System.out.println("대출되었습니다.\n");
					dao.rentTitle2(titleNum); // 대출유무 변수 변경 쿼리소환 메소드
					dao.plusRentMoney();
					return;
				}
			}
		} 
		System.out.println("잘못된 입력입니다.\n");
		
	}
	
	private void memberRent() {
		System.out.println("=====대여 내역 조회=====\n");
		ArrayList<Title> list = dao.rentList(dao.personNumToacoNum(loginpersonNum));
		if (list == null || list.size() == 0) {
			System.out.println("대여 내역이 없습니다.\n");
			return;
		}
		System.out.println("번호\t\t타이틀명\t\t반납예정일");
		System.out.println("=============================================");
		for (Title t : list) {
			System.out.print(t.getTitle_num() + "\t\t");
			System.out.print(t.getTitle_name() + "\t\t");
			System.out.println(dao.getReturnDate(t.getTitle_num()));
		}
		
		System.out.println("=============================================");
		
		System.out.println("\n1. 반납");
		System.out.println("2. 대여 기간 연장");
		System.out.print("선택 : ");
		int col = 0;
		try {
			col = sc.nextInt();
		} catch (Exception e) {
			sc.nextLine();
		}
		switch (col) {
		case 1:
			returnTitle();
			break;
		case 2:
			extendRentday();
			break;
		default:
			System.out.println("올바른 번호를 입력하세요.\n");
		}
	}
	
	private void returnTitle() {
		System.out.println("=====반납 메뉴=====\n");
		System.out.print("반납하실 타이틀 번호 입력 : ");
		int titleNum = 0;
		try {
			titleNum = sc.nextInt();
		} catch (Exception e) {
			sc.nextLine();
		}
		boolean res = dao.returnTitle(titleNum);
		if (res) {
			dao.returnTitle2(titleNum);
			System.out.println("반납되었습니다.\n");
		}
		else System.out.println("올바른 타이틀 번호를 입력하세요.\n");
	}
	
	private void extendRentday() {
		System.out.println("=====연장 메뉴=====\n");
		System.out.print("연장할 타이틀 번호 입력 : ");
		int titleNum = 0;
		try {
			titleNum = sc.nextInt();
		} catch (Exception e) {
			sc.nextLine();
		}
		boolean res = dao.plusReturnDate(titleNum);
		if (res) {
			System.out.println("대여기간 연장되었습니다.\n");
			dao.plusExtendMoney();
		}
		else System.out.println("올바른 타이틀 번호를 입력하세요.\n");
	}
	
}