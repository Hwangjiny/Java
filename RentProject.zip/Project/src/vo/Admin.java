package vo;

public class Admin {
	private int admin_num;
	private int admin_money;
	
	public Admin() {
		// TODO Auto-generated constructor stub
	}

	public Admin(int admin_num, int admin_money) {
		super();
		this.admin_num = admin_num;
		this.admin_money = admin_money;
	}

	public int getAdmin_num() {
		return admin_num;
	}

	public void setAdmin_num(int admin_num) {
		this.admin_num = admin_num;
	}

	public int getAdmin_money() {
		return admin_money;
	}

	public void setAdmin_money(int admin_money) {
		this.admin_money = admin_money;
	}

	@Override
	public String toString() {
		return "Admin [admin_num=" + admin_num + ", admin_money=" + admin_money + "]";
	}
}
