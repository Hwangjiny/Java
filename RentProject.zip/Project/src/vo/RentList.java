package vo;

public class RentList {
	private int rent_num;
	private int aco_num;
	private int titlenum;
	private String rentday;

	public RentList(int rent_num, int aco_num, int titlenum, String rentday) {
		super();
		this.rent_num = rent_num;
		this.aco_num = aco_num;
		this.titlenum = titlenum;
		this.rentday = rentday;
	}

	public RentList(int aco_num, int titlenum) {
		super();
		this.aco_num = aco_num;
		this.titlenum = titlenum;
	}

	public int getRent_num() {
		return rent_num;
	}

	public void setRent_num(int rent_num) {
		this.rent_num = rent_num;
	}

	public int getAco_num() {
		return aco_num;
	}

	public void setAco_num(int aco_num) {
		this.aco_num = aco_num;
	}

	public int getTitlenum() {
		return titlenum;
	}

	public void setTitlenum(int titlenum) {
		this.titlenum = titlenum;
	}

	public String getRentday() {
		return rentday;
	}

	public void setRentday(String rentday) {
		this.rentday = rentday;
	}

	@Override
	public String toString() {
		return "RentList [rent_num=" + rent_num + ", aco_num=" + aco_num + ", titlenum=" + titlenum + ", rentday="
				+ rentday + "]";
	}
	
	
}
