package vo;

public class Account {
	private int num;
	private String name;
	private String person_Num;
	private String phone_Num;
	private String password;
	private int aco_money;
	

	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	public Account(String name, String person_Num, String phone_Num, String password, int aco_money) {
		super();
		this.name = name;
		this.person_Num = person_Num;
		this.phone_Num = phone_Num;
		this.password = password;
		this.aco_money = aco_money;
	}

	public Account(int num, String name, String person_Num, String phone_Num) {
		super();
		this.num = num;
		this.name = name;
		this.person_Num = person_Num;
		this.phone_Num = phone_Num;
	}
	
	public Account(int num, String name, String person_Num, String phone_Num, String password, int aco_money) {
		super();
		this.num = num;
		this.name = name;
		this.person_Num = person_Num;
		this.phone_Num = phone_Num;
		this.password = password;
		this.aco_money = aco_money;
	}

	public Account(int num, String name, String person_Num, String phone_Num, String password) {
		super();
		this.num = num;
		this.name = name;
		this.person_Num = person_Num;
		this.phone_Num = phone_Num;
		this.password = password;
	}

	public Account(String name, String person_Num, String phone_Num, String password) {
		super();
		this.name = name;
		this.person_Num = person_Num;
		this.phone_Num = phone_Num;
		this.password = password;
	}

	public Account(String person_Num, String phone_Num) {
		super();
		this.person_Num = person_Num;
		this.phone_Num = phone_Num;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPerson_Num() {
		return person_Num;
	}

	public void setPerson_Num(String person_Num) {
		this.person_Num = person_Num;
	}

	public String getPhone_Num() {
		return phone_Num;
	}

	public void setPhone_Num(String phone_Num) {
		this.phone_Num = phone_Num;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public int getMoney() {
		return aco_money;
	}

	public void setMoney(int aco_money) {
		this.aco_money = aco_money;
	}
	
	@Override
	public String toString() {
		return "Account [num=" + num + ", name=" + name + ", person_Num=" + person_Num + ", phone_Num=" + phone_Num
				+ ", password=" + password + ", aco_money=" + aco_money + "]";
	}
}	
