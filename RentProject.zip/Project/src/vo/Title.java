package vo;

public class Title {
	private int title_num;
	private String title_name;
	private String title_genre;
	private String title_date;
	private int rent_stat;
	
	public Title() {
		// TODO Auto-generated constructor stub
	}
	
	public Title(int title_num, String title_name, String title_genre, String title_date, int rent_stat) {
		super();
		this.title_num = title_num;
		this.title_name = title_name;
		this.title_genre = title_genre;
		this.title_date = title_date;
		this.rent_stat = rent_stat;
	}

	public Title(int title_num, String title_name, String title_genre, String title_date) {
		super();
		this.title_num = title_num;
		this.title_name = title_name;
		this.title_genre = title_genre;
		this.title_date = title_date;
	}

	public int getTitle_num() {
		return title_num;
	}

	public void setTitle_num(int title_num) {
		this.title_num = title_num;
	}

	public String getTitle_name() {
		return title_name;
	}

	public void setTitle_name(String title_name) {
		this.title_name = title_name;
	}

	public String getTitle_genre() {
		return title_genre;
	}

	public void setTitle_genre(String title_genre) {
		this.title_genre = title_genre;
	}

	public String getTitle_date() {
		return title_date;
	}

	public void setTitle_date(String title_date) {
		this.title_date = title_date;
	}
	
	public int getRent_stat() {
		return rent_stat;
	}

	public void setRent_stat(int rent_stat) {
		this.rent_stat = rent_stat;
	}

	@Override
	public String toString() {
		return "Title [title_num=" + title_num + ", title_name=" + title_name + ", title_genre=" + title_genre
				+ ", title_date=" + title_date + "]";
	}
	
}
