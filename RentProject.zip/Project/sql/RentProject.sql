CREATE TABLE Account(
    num NUMBER PRIMARY KEY,
    name VARCHAR2(20) NOT NULL,
    person_num VARCHAR2(20) NOT NULL,
    phone_num VARCHAR2(20) NOT NULL,
    password VARCHAR2(30) NOT NULL,
    aco_money NUMBER
);

CREATE TABLE Admin_title(
title_num NUMBER PRIMARY KEY,
title_name VARCHAR2(100) NOT NULL UNIQUE,
title_genre VARCHAR2(20) NOT NULL ,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               
title_date VARCHAR2(20) NOT NULL,
rent_stat NUMBER
);

CREATE TABLE Admin(
admin_num NUMBER PRIMARY KEY ,
admin_money NUMBER not null
);

create table RentList(
    rent_num NUMBER PRIMARY KEY,
    aco_num number not null,
    titlenum number not null,
    rentday date default sysdate,
    
    constraint fk_num foreign key (aco_num)
    references account(num) ON DELETE CASCADE,
    constraint fk_titlenum foreign key (titlenum)
    references admin_title(title_num) ON DELETE CASCADE
);


CREATE SEQUENCE rentlist_seq;
CREATE SEQUENCE Account_num;
CREATE SEQUENCE Admin_title_seq;
CREATE SEQUENCE Admin_seq;

DROP SEQUENCE Account_num;
DROP SEQUENCE Admin_title_seq;
DROP SEQUENCE renlist_seq;
DROP SEQUENCE Admin_seq;
DROP TABLE rentlist;
DROP TABLE account;
DROP TABLE admin_title;
DROP TABLE Admin;

COMMIT;



INSERT INTO Admin(admin_num, admin_money)
VALUES(Admin_seq.nextval, 1000000);

INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '홍길동', '700000', '055', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '홍길순', '710000', '054', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '홍길철', '720000', '053', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '홍민규', '730000', '052', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '홍승철', '740000', '051', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '홍가희', '750000', '050', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '홍민정', '760000', '031', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '황혁진', '770000', '032', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '황희', '780000', '03', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '황민호', '790000', '034', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '황수민', '800000', '035', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '황세영', '810000', '011', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '전우치', '820000', '018', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '전태일', '830000', '017', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '전성민', '840000', '019', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김개통', '850000', '010', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김기쁨', '860000', '070', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김소망', '870000', '080', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김규동', '880000', '090', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김군인', '890000', '1541', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김라면', '900000', '7782', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김떡순', '910000', '7783', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김고기', '920000', '5539', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김서림', '930000', '7639', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김치득', '940000', '5563', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '김동안', '950000', '6382', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '이삿짐', '960000', '6794', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '이대리', '970000', '1544', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '성주임', '980000', '5587', '1111', 0);
INSERT INTO Account(num, name, person_num, phone_num, password, aco_money)
VALUES(Account_num.nextval, '정사장', '990000', '1493', '1111', 0);

INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '컨저링', '공포', '2013', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '사일런트 힐', '공포', '2006', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '사탄의 인형', '공포', '1991', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '오펀:천사의 비밀', '공포', '2009', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '여고괴담', '공포', '1998', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '파라노말 액티비티', '공포', '2010', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '고스트 쉽', '공포', '2002', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '애나벨', '공포', '2014', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '주온', '공포', '2003', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '몬몬몬 몬스터', '공포', '2018', 1);

INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '82년생 김지영', '드라마', '2019', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '신세계', '드라마', '2013', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '조커', '드라마', '2019', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '캐스트 어웨이', '드라마', '2001', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '아마데우스', '드라마', '1985', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '코러스', '드라마', '2005', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '도가니', '드라마', '2011', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '피아니스트', '드라마', '2003', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '아이 앰 샘', '드라마', '2002', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '패왕별희', '드라마', '1993', 1);

INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '겨울왕국 2', '판타지', '2019', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '쥬만지', '판타지', '1996', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '피아니스트의 전설', '판타지', '2002', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '반지의 제왕 3', '판타지', '2003', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '천녀유혼', '판타지', '1987', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '찰리와 초콜릿 공장', '판타지', '2005', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '캐리비안의 해적', '판타지', '2006', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '큐브', '판타지', '1999', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '비밀', '판타지', '2002', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '스타더스트', '판타지', '2007', 1);

INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '지금 만나러 갑니다', '멜로', '2005', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '말할 수 없는 비밀', '멜로', '2008', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '첫 키스만 50번째', '멜로', '2004', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '사랑과 영혼', '멜로', '1990', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '어바웃 타임', '멜로', '2013', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '타이타닉', '멜로', '1998', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '클래식', '멜로', '2003', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '이터널 선샤인', '멜로', '2005', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '첨밀밀', '멜로', '1997', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '러브 앳', '멜로', '2019', 1);

INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '세 얼간이', '코미디', '2011', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '트루먼 쇼', '코미디', '1998', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '엽기적인 그녀', '코미디', '2001', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '스쿨 오브 락', '코미디', '2004', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '과속스캔들', '코미디', '2008', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '영구와 땡칠이', '코미디', '1998', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '기쿠지로의 여름', '코미디', '2002', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '인턴', '코미디', '2015', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '결혼 이야기', '코미디', '2019', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '우드잡', '코미디', '2015', 1);

INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '센과 치히로의 행방불명', '애니메이션', '2002', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '토이 스토리 3', '애니메이션', '2010', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '주토피아', '애니메이션', '2016', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '라이온 킹', '애니메이션', '1994', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '시간을 달리는 소녀', '애니메이션', '2007', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '모아나', '애니메이션', '2017', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '주먹왕 랄프', '애니메이션', '2012', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '월-E', '애니메이션', '2008', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '드래곤 길들이기 3', '애니메이션', '2019', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '라푼젤', '애니메이션', '2011', 1);

INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '포드 V 페라리', '액션', '2019', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '글래디에이터', '액션', '2000', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '클레멘타인', '액션', '2004', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '해바라기', '액션', '2006', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '영웅본색', '액션', '1987', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '도망자', '액션', '1993', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '정무문', '액션', '1973', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '테이큰', '액션', '2008', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '다이 하드', '액션', '1988', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '어벤져스:엔드게임', '액션', '2019', 1);

INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '살인의 추억', '범죄', '2003', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '레옹', '범죄', '1995', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '공공의 적', '범죄', '2002', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '타짜', '범죄', '2006', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '내부자들', '범죄', '2015', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '대부', '범죄', '1977', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '어 퓨 굿맨', '범죄', '1992', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '트레인스포팅', '범죄', '1997', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '홀리데이', '범죄', '2006', 1);
INSERT INTO Admin_title(title_num, title_name, title_genre, title_date, rent_stat)
VALUES (Admin_titleNum.nextval, '무간도', '범죄', '2003', 1);

COMMIT;




SELECT * FROM admin_title;
SELECT * FROM Rentlist;
SELECT * FROM Account;
SELECT * FROM rentlist;
SELECT * FROM Admin;
